clear all;
clc;
for i=1:1338    
    imagefeaturedataSC10_lable(i)=1;
    imagefeaturedataSC00_lable(i)=0;
end

save imagefeaturedata_lable;
% save imagefeaturedataSC00_lable.mat imagefeaturedataSC00_lable;
% save imagefeaturedataSC10_lable.mat imagefeaturedataSC00_lable;