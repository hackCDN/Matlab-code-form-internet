clear all;
clc;
close all;

OpenPathName='D:\ucid.v2\SI10';
dir_source=dir(OpenPathName);

ImageNo=0;
% for item=4:5
for item=4:size(dir_source,1)
    FileName_s=dir_source(item).name;
    FullPathName_s = [OpenPathName,'\',FileName_s];
    orgimage=imread(FullPathName_s);
    Z=imread(FullPathName_s);
    figure(1)
    imagesc(Z)
%     orgimage = imread('2_1.bmp');
%     orgimage = imread('SC10ucid00001.tif');
    orgimage = rgb2gray(orgimage);
    imshow(orgimage);
    orgimage = double(orgimage);
    [image_height,image_width]=size(orgimage);

    for s=1:image_height
        for t=1:image_width
            patchtypeimage(s,t)=10;
        end
    end
    
    for m=1:2:(image_height-2)
        p=m+1;
        for n=1:2:(image_width-3)
            q=n+1;
            % Image Mini-squares %
            minisquare(1,1) = orgimage(p,q);
            minisquare(1,2) = orgimage(p,q+1);
            minisquare(2,1) = orgimage(p+1,q);
            minisquare(2,2) = orgimage(p+1,q+1);

            % Mini-Squares of patches %
            patch0 = [round(((orgimage(p,q-1)+minisquare(1,1))/2)) minisquare(1,1) minisquare(1,2);round(((orgimage(p+1,q-1)+minisquare(2,1))/2)) minisquare(2,1) minisquare(2,2)];
            patch1 = [round(((orgimage(p,q-1)+minisquare(1,1))/2)) minisquare(1,1) minisquare(1,2);minisquare(2,1) round(((minisquare(2,1)+minisquare(2,2))/2)) minisquare(2,2)];
            patch2 = [round(((orgimage(p,q-1)+minisquare(1,1))/2)) minisquare(1,1) minisquare(1,2);minisquare(2,1) minisquare(2,2) round(((orgimage(p+1,q+2)+minisquare(2,2))/2))];
            patch3 = [minisquare(1,1) round(((minisquare(1,1)+minisquare(1,2))/2)) minisquare(1,2);round(((orgimage(p+1,q-1)+minisquare(2,1))/2)) minisquare(2,1) minisquare(2,2)];
            patch4 = [minisquare(1,1) round(((minisquare(1,1)+minisquare(1,2))/2)) minisquare(1,2);minisquare(2,1) round(((minisquare(2,1)+minisquare(2,2))/2)) minisquare(2,2)];
            patch5 = [minisquare(1,1) round(((minisquare(1,1)+minisquare(1,2))/2)) minisquare(1,2);minisquare(2,1) minisquare(2,2) round(((orgimage(p+1,q+2)+minisquare(2,2))/2))];
            patch6 = [minisquare(1,1) minisquare(1,2) round(((orgimage(p,q+2)+minisquare(1,2))/2));round(((orgimage(p+1,q-1)+minisquare(2,1))/2)) minisquare(2,1) minisquare(2,2)];
            patch7 = [minisquare(1,1) minisquare(1,2) round(((orgimage(p,q+2)+minisquare(1,2))/2));minisquare(2,1) round(((minisquare(2,1)+minisquare(2,2))/2)) minisquare(2,2)];
            patch8 = [minisquare(1,1) minisquare(1,2) round(((orgimage(p,q+2)+minisquare(1,2))/2));minisquare(2,1) minisquare(2,2) round(((orgimage(p+1,q+2)+minisquare(2,2))/2))];

            % Mini-Squares of referee pattern %
            for a = 0:1
                for b = 0:1
    %                 tmp_referee_pattern = double([orgimage(p-1+a,q-1+b) orgimage(p-1+a,q+b) orgimage(p-1+a,q+1+b);orgimage(p+1+a,q-1+b) orgimage(p+1+a,q+b) orgimage(p+1+a,q+1+b)]);
                    tmp_referee_pattern = [orgimage(p-1+a,q-1+b) orgimage(p-1+a,q+b) orgimage(p-1+a,q+1+b);orgimage(p+1+a,q-1+b) orgimage(p+1+a,q+b) orgimage(p+1+a,q+1+b)];
                    if (a==0 && b==0)
                        referee_pattern = tmp_referee_pattern;
                    else
                        referee_pattern = referee_pattern + tmp_referee_pattern;
                    end
    %                 tmp_referee_pattern(1,1) = double(orgimage(p-1+a,q-1+b));
    %                 tmp_referee_pattern(1,2) = orgimage(p-1+a,q+b);
    %                 tmp_referee_pattern(1,3) = orgimage(p-1+a,q+1+b);
    %                 tmp_referee_pattern(2,1) = orgimage(p+1+a,q-1+b);
    %                 tmp_referee_pattern(2,2) = orgimage(p+1+a,q+b);
    %                 tmp_referee_pattern(2,3) = orgimage(p+1+a,q+1+b);                              
                end
            end
            referee_pattern = (referee_pattern/4);

            % Criterion of Cosine similarity %
            patch_criterion(1) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch0(1,:) patch0(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch0(1,:) patch0(2,:)]));
            patch_criterion(2) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch1(1,:) patch1(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch1(1,:) patch1(2,:)]));
            patch_criterion(3) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch2(1,:) patch2(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch2(1,:) patch2(2,:)]));
            patch_criterion(4) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch3(1,:) patch3(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch3(1,:) patch3(2,:)]));
            patch_criterion(5) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch4(1,:) patch4(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch4(1,:) patch4(2,:)]));
            patch_criterion(6) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch5(1,:) patch5(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch5(1,:) patch5(2,:)]));
            patch_criterion(7) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch6(1,:) patch6(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch6(1,:) patch6(2,:)]));
            patch_criterion(8) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch7(1,:) patch7(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch7(1,:) patch7(2,:)]));
            patch_criterion(9) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch8(1,:) patch8(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch8(1,:) patch8(2,:)]));

            % Select Mini-Squares of patches %
            [patch_value patch_index]=max(patch_criterion);
            patch_index = patch_index-1;       

            % Image patchtype %
            patchtypeimage(p,q) = patch_index;
            patchtypeimage(p,q+1) = patch_index;
            patchtypeimage(p+1,q) = patch_index;
            patchtypeimage(p+1,q+1) = patch_index;

            clear patch_index patch_value patch_criterion;
        end
    end
    
%     for m=(image_height-2):(-2):2
%         p=m+1;
%         for n=(image_width-3):(-2):2
%             q=n+1;
%             % Image patchtype %
%             patch_index = patchtypeimage(p,q);            
%             
%             % My propose %             
%             switch patch_index
%                 case{0,1}
%                     parent_patch_index = patchtypeimage(p-1,q-1);                    
%                     if (parent_patch_index==2 || parent_patch_index==5 || parent_patch_index==8)
%                         Ms_patchtypeimage(p,q) = 255;
%                         Ms_patchtypeimage(p,q+1) = 255;
%                         Ms_patchtypeimage(p+1,q) = 255;
%                         Ms_patchtypeimage(p+1,q+1) = 255;
%                         clear parent_patch_index;
%                     else
%                         Md_patchtypeimage(p,q) = 0;
%                         Md_patchtypeimage(p,q+1) = 0;
%                         Md_patchtypeimage(p+1,q) = 0;
%                         Md_patchtypeimage(p+1,q+1) = 0;
%                     end                    
%                     parent_patch_index = patchtypeimage(p-1,q); 
%                     switch parent_patch_index                     
%                         case{0,1,3,4,6,7}
%                             Mv_patchtypeimage(p,q) = 255;
%                             Mv_patchtypeimage(p,q+1) = 255;
%                             Mv_patchtypeimage(p+1,q) = 255;
%                             Mv_patchtypeimage(p+1,q+1) = 255;
%                             clear parent_patch_index;                            
%                     end
%                     
%                 case{3,4,5}
%                     parent_patch_index = patchtypeimage(p-1,q); 
%                     switch parent_patch_index                     
%                         case{0,1,2,3,4,5,6,7,8}
%                             Mv_patchtypeimage(p,q) = 255;
%                             Mv_patchtypeimage(p,q+1) = 255;
%                             Mv_patchtypeimage(p+1,q) = 255;
%                             Mv_patchtypeimage(p+1,q+1) = 255;
%                             clear parent_patch_index;                            
%                     end
%                     
%                 case{7,8}
%                     parent_patch_index = patchtypeimage(p-1,q); 
%                     switch parent_patch_index                     
%                         case{1,2,4,5,7,8}
%                             Mv_patchtypeimage(p,q) = 255;
%                             Mv_patchtypeimage(p,q+1) = 255;
%                             Mv_patchtypeimage(p+1,q) = 255;
%                             Mv_patchtypeimage(p+1,q+1) = 255;
%                             clear parent_patch_index;
%                     end     
%                     parent_patch_index = patchtypeimage(p-1,q+2);                    
%                     if (parent_patch_index==0 || parent_patch_index==3 || parent_patch_index==6)
%                         Md_patchtypeimage(p,q) = 255;
%                         Md_patchtypeimage(p,q+1) = 255;
%                         Md_patchtypeimage(p+1,q) = 255;
%                         Md_patchtypeimage(p+1,q+1) = 255;
%                         clear parent_patch_index;
%                     else
%                         Md_patchtypeimage(p,q) = 0;
%                         Md_patchtypeimage(p,q+1) = 0;
%                         Md_patchtypeimage(p+1,q) = 0;
%                         Md_patchtypeimage(p+1,q+1) = 0;
%                     end
%             end
%             
%         end
%     end
%     
% figure(2);
% % imagesc(Ms_patchtypeimage);
% imshow(Ms_patchtypeimage);
% figure(3);
% % imagesc(Mv_patchtypeimage);
% imshow(Mv_patchtypeimage);
% figure(4);
% % imagesc(Md_patchtypeimage);
% imshow(Md_patchtypeimage);
% 
% tmp_a =and(Ms_patchtypeimage,Mv_patchtypeimage);
% tmp_b = and(tmp_a,Md_patchtypeimage);
% figure(5);
% % imagesc(Md_patchtypeimage);
% imshow(tmp_b);
    
    % Probability of patchtype for everyone % 
    TotalHistogramCount=zeros(10,1);
    for level=0:9
        TotalHistogramCount(level+1)=(sum(sum(patchtypeimage==level)));
    end
    % bar(TotalHistogramCount);
    % set(gca,'XLim',[0 10]);
    % xlabel('patchtype');
    % ylabel('total');

    % Markov Feaature Transition Probability Matrix %

    for a=0:8
        for b=0:8 

            % Transition Probability Matrix of subdiagonal Function Ms(a,b) %
            msindex_count=0;
            for s=1:image_height
                for t=1:image_width
                    if (patchtypeimage(s,t)==a && patchtypeimage(s+1,t-1)==b)
                        msindex_count = msindex_count+1;
                    end
                end
            end        
            ms_matrix_feature(a+1,b+1) = msindex_count/TotalHistogramCount(a+1);
            ms_feature(9*a+b+1) = ms_matrix_feature(a+1,b+1);
            clear msindex_count;

            % Transition Probability Matrix of vertical Mv(a,b) %
            mvindex_count=0;
            for s=1:image_height
                for t=1:image_width
                    if (patchtypeimage(s,t)==a && patchtypeimage(s+1,t)==b)
                        mvindex_count = mvindex_count+1;
                    end
                end
            end        
            mv_matrix_feature(a+1,b+1) = mvindex_count/TotalHistogramCount(a+1);
            mv_feature(9*a+b+1) = mv_matrix_feature(a+1,b+1);
            clear mvindex_count;

            % Transition Probability Matrix of diagonal Md(a,b) %
             mdindex_count=0;
            for s=1:image_height
                for t=1:image_width
                    if (patchtypeimage(s,t)==a && patchtypeimage(s+1,t+1)==b)
                        mdindex_count = mdindex_count+1;
                    end
                end
            end        
            md_matrix_feature(a+1,b+1) = mdindex_count/TotalHistogramCount(a+1);
            md_feature(9*a+b+1) = md_matrix_feature(a+1,b+1);
            clear mdindex_count;        
        end
    end
    imagefeature = [(TotalHistogramCount(1:9)/(image_height*image_width))',ms_feature,mv_feature,md_feature];

    
    % Save Features to SVM input file %
    ImageNo=ImageNo+1
    imagefeaturedata(ImageNo,:)=imagefeature;
    showitem=FileName_s
end

imagefeaturedataSI10 = imagefeaturedata;
save imagefeaturedataSI10.mat imagefeaturedataSI10;
