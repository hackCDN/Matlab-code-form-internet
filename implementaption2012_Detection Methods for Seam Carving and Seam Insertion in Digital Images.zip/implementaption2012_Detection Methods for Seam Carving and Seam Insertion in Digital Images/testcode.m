clear all;
clc;

patchtypeimage = [2,2,6,6,2,2,1,1,5;2,2,6,6,2,2,1,1,5;4,4,7,7,2,2,3,3,6;4,4,7,7,2,2,3,3,6;5,5,5,5,2,2,6,6,3;5,5,5,5,2,2,6,6,3;7,7,2,2,2,2,7,7,5;7,7,2,2,2,2,7,7,5;0,0,7,7,3,3,8,8,2;0,0,7,7,3,3,8,8,2;2,2,5,5,8,8,3,3,4;2,2,5,5,8,8,3,3,4;0,0,3,3,0,0,6,6,6;0,0,3,3,0,0,6,6,6;4,4,3,3,0,0,7,7,7;4,4,3,3,0,0,7,7,7;0,0,7,7,7,7,6,6,4;0,0,7,7,7,7,6,6,4;8,8,4,4,5,5,6,6,7;8,8,4,4,5,5,6,6,7;]*10
[i,j]=size(patchtypeimage);

imshow(patchtypeimage,[0 255]);

for s=1:i
    for t=1:j     
        patch_index = patchtypeimage(s,t);
        switch patch_index
            case patch_index==0
                if (patchtypeimage(s+1,t)==0||patchtypeimage(s+1,t)==1||patchtypeimage(s+1,t)==3||patchtypeimage(s+1,t)==4||patchtypeimage(s+1,t)==5)
                    patchtypeimage_show(s,t) = 255;
                end                
            case patch_index==1
                if (patchtypeimage(s+1,t)==1||patchtypeimage(s+1,t)==0||patchtypeimage(s+1,t)==3||patchtypeimage(s+1,t)==4||patchtypeimage(s+1,t)==5||patchtypeimage(s+1,t)==7||patchtypeimage(s+1,t)==8)
                    patchtypeimage_show(s,t) = 255;
                end  
            case patch_index==3
                if (patchtypeimage(s+1,t)==3||patchtypeimage(s+1,t)==0||patchtypeimage(s+1,t)==1||patchtypeimage(s+1,t)==4||patchtypeimage(s+1,t)==5)
                    patchtypeimage_show(s,t) = 255;
                end         
            case patch_index==4
                if (patchtypeimage(s+1,t)==4||patchtypeimage(s+1,t)==0||patchtypeimage(s+1,t)==1||patchtypeimage(s+1,t)==3||patchtypeimage(s+1,t)==5||patchtypeimage(s+1,t)==7||patchtypeimage(s+1,t)==8)
                    patchtypeimage_show(s,t) = 255;
                end 
            case patch_index==5
                if (patchtypeimage(s+1,t)==5||patchtypeimage(s+1,t)==3||patchtypeimage(s+1,t)==4||patchtypeimage(s+1,t)==7||patchtypeimage(s+1,t)==8)
                    patchtypeimage_show(s,t) = 255;
                end
            case patch_index==7
                if (patchtypeimage(s+1,t)==7||patchtypeimage(s+1,t)==0||patchtypeimage(s+1,t)==1||patchtypeimage(s+1,t)==3||patchtypeimage(s+1,t)==4||patchtypeimage(s+1,t)==5||patchtypeimage(s+1,t)==8)
                    patchtypeimage_show(s,t) = 255;
                end 
            case patch_index==8
                if (patchtypeimage(s+1,t)==8||patchtypeimage(s+1,t)==3||patchtypeimage(s+1,t)==4||patchtypeimage(s+1,t)==5||patchtypeimage(s+1,t)==7)
                    patchtypeimage_show(s,t) = 255;
                end 
            otherwise
                patchtypeimage_show(s,t) = 20;
        end
    end
end
imshow(patchtypeimage_show,[0 255]);


% % orgimage = [138 132 153 153 138 149;74 90 112 139 152 122;63 72 85 74 68 61;70 75 61 40 34 35]
% % orgimage = [64 64 64 64 64 64;64 64 64 64 64 64;64 64 64 64 64 64;64 64 64 64 64 64]
% % orgimage = [69,68,68,68,68,68;69,69,69,69,69,69;69,69,70,70,70,70;70,71,71,71,71,71]
% orgimage = [69,69,69,72,72,72;69,69,69,72,72,72;69,69,69,72,72,72;70,70,70,72,72,72]
% 
% p=2;
% q=3;
% mini_square(1,1) = orgimage(p,q);
% mini_square(1,2) = orgimage(p,q+1);
% mini_square(2,1) = orgimage(p+1,q);
% mini_square(2,2) = orgimage(p+1,q+1);
% 
% patche0 = [round(((orgimage(p,q-1)+mini_square(1,1))/2)) mini_square(1,1) mini_square(1,2);round(((orgimage(p+1,q-1)+mini_square(2,1))/2)) mini_square(2,1) mini_square(2,2)];
% patche1 = [round(((orgimage(p,q-1)+mini_square(1,1))/2)) mini_square(1,1) mini_square(1,2);mini_square(2,1) round(((mini_square(2,1)+mini_square(2,2))/2)) mini_square(2,2)];
% patche2 = [round(((orgimage(p,q-1)+mini_square(1,1))/2)) mini_square(1,1) mini_square(1,2);mini_square(2,1) mini_square(2,2) round(((orgimage(p+1,q+2)+mini_square(2,2))/2))];
% patche3 = [mini_square(1,1) round(((mini_square(1,1)+mini_square(1,2))/2)) mini_square(1,2);round(((orgimage(p+1,q-1)+mini_square(2,1))/2)) mini_square(2,1) mini_square(2,2)];
% patche4 = [mini_square(1,1) round(((mini_square(1,1)+mini_square(1,2))/2)) mini_square(1,2);mini_square(2,1) round(((mini_square(2,1)+mini_square(2,2))/2)) mini_square(2,2)];
% patche5 = [mini_square(1,1) round(((mini_square(1,1)+mini_square(1,2))/2)) mini_square(1,2);mini_square(2,1) mini_square(2,2) round(((orgimage(p+1,q+2)+mini_square(2,2))/2))];
% patche6 = [mini_square(1,1) mini_square(1,2) round(((orgimage(p,q+2)+mini_square(1,2))/2));round(((orgimage(p+1,q-1)+mini_square(2,1))/2)) mini_square(2,1) mini_square(2,2)];
% patche7 = [mini_square(1,1) mini_square(1,2) round(((orgimage(p,q+2)+mini_square(1,2))/2));mini_square(2,1) round(((mini_square(2,1)+mini_square(2,2))/2)) mini_square(2,2)];
% patche8 = [mini_square(1,1) mini_square(1,2) round(((orgimage(p,q+2)+mini_square(1,2))/2));mini_square(2,1) mini_square(2,2) round(((orgimage(p+1,q+2)+mini_square(2,2))/2))];
% 
% for a = 0:1
%     for b = 0:1
%         tmp_referee_pattern = [orgimage(p-1+a,q-1+b) orgimage(p-1+a,q+b) orgimage(p-1+a,q+1+b);orgimage(p+1+a,q-1+b) orgimage(p+1+a,q+b) orgimage(p+1+a,q+1+b)]
%         if (a==0 && b==0)
%             referee_pattern = tmp_referee_pattern;
%         else 
%             referee_pattern = referee_pattern + tmp_referee_pattern;
%         end
%     end
% end
% referee_pattern = (referee_pattern/4);
% 
% % patch_criterion = [2,2,2,2,2,2,2,2];
% patch_criterion(1) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche0(1,:) patche0(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche0(1,:) patche0(2,:)]));
% patch_criterion(2) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche1(1,:) patche1(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche1(1,:) patche1(2,:)]));
% patch_criterion(3) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche2(1,:) patche2(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche2(1,:) patche2(2,:)]));
% patch_criterion(4) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche3(1,:) patche3(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche3(1,:) patche3(2,:)]));
% patch_criterion(5) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche4(1,:) patche4(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche4(1,:) patche4(2,:)]));
% patch_criterion(6) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche5(1,:) patche5(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche5(1,:) patche5(2,:)]));
% patch_criterion(7) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche6(1,:) patche6(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche6(1,:) patche6(2,:)]));
% patch_criterion(8) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche7(1,:) patche7(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche7(1,:) patche7(2,:)]));
% patch_criterion(9) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche8(1,:) patche8(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche8(1,:) patche8(2,:)]));
% 
% for n=1:100
% [patch_value patch_index]=max(patch_criterion)
% % clear patch_index patch_value patch_criterion;
% clear patch_index;
% end
