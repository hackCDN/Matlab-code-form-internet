
% Seam-Carving demo.
% Current version works with 3-channel images. If you input a 1-channel
% image, it automatically replicates it to a 3-channel image
%
% This code is based on the paper:
% 
% Improved Seam Carving for Video Retargeting
% Michael Rubinstein, Ariel Shamir, Shai Avidan
% ACM Transactions on Graphics, Volume 27, Number 3 SIGGRAPH 2008
% 
% Michael Rubinstein, IDC 2008

close all
clear all
clc

% imagename = 'waterfall.png';

OpenPathName='D:\ucid.v2';
dir_source=dir(OpenPathName);
SavePathName='D:\ucid.v2\SC10';
dir_target=dir(SavePathName);
dir_target=dir_source;

seamsize='SC10';
resize_P=0.9;

for item=11:size(dir_source,1)
    
%--- Parameters ---%

p.piecewiseThresh = 9e9; % threshold for piecewise-connected seams (see seamConstructPathPiecewise). Set to very large value to ignore
p.method = 'backward'; % 'backward' or 'forward'
p.seamFunc = @seamPath_dp; % @seamPath_dp for dynamic programming, @seamPath_gcut for graph-cut
p.s = 1; % permissible seam step (used by seamPath_dp)
p.errFunc.name = @errL1; % error function (used by backward energy)
p.errFunc.weightNorm = @errWeightAdd; % function for incorporating additional weight map (used by backward energy)

%--- Run ---%
FileName_s=dir_source(item).name;
FullPathName_s = [OpenPathName,'\',FileName_s];
I = im2double(imread(FullPathName_s));
% I = im2double(imread(imagename));
nChannels=size(I,3);
if (nChannels == 1)
    I = repmat(I,[1,1,3]);
end
[height,width,nChannels] = size(I);

% target size (change either width or height, but not both).
% maintain target size within bounds of the image, otherwise will cause 
% an index out of bounds error.

% new_width = floor(.75*width);
new_width = floor(resize_P*width); 
new_height = height;

% J is the retargeted image, S is the seams map
[J,S] = imretarget(I,[new_height,new_width],[],p);
GT = seamOverlay(I,S);

figure; imshow(I); title('Input');
figure; imshow(J); title('Retarget');
% figure; imshow(seamOverlay(I,S)); title('Seams');
figure; imshow(GT); title('Seams');

FileName_t=dir_target(item).name;
FullPathName_t1 = [SavePathName,'\',p.method,'\',seamsize,FileName_t]; 
FullPathName_t2 = [SavePathName,'\',p.method,'\','GroundTruth',seamsize,FileName_t];
imwrite(J,FullPathName_t1);
imwrite(GT,FullPathName_t2);

showitem=FileName_t

end
