function G = errWeightAdd(G,W)

G = G+W;

return;