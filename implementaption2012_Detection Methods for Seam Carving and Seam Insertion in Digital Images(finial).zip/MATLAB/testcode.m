clear all;
clc;

% load imagefeaturedataSI30.mat;

TotalHistogramCount=zeros(9,1);

% data01 %
patchtypeimage01=[0,0,0,0;1,0,1,0;4,4,4,0;1,0,1,1;5,0,0,4;8,1,1,0;1,0,2,0;0,1,2,1;2,5,5,3;];
% data02 %
patchtypeimage02=[7,3,6,1;2,6,8,3;3,3,3,0;5,8,2,7;0,8,6,0;7,2,0,1;6,0,7,0;6,4,1,0;5,1,3,6;];
% data03 %
patchtypeimage03=[0,1,2,0;0,0,4,2;3,0,3,0;0,5,0,0;0,0,3,3;0,3,4,7;0,3,0,0;6,0,6,0;6,0,6,0;0,2,1,1;2,0,0,0;];
% data04 %
patchtypeimage04=[0,1,0,6,6;7,6,0,2,6;5,7,6,8,8;1,4,2,1,2;2,0,5,3,2;1,6,1,4,5;8,3,1,1,1;0,3,8,1,7;8,2,0,0,0;0,6,0,8,7;2,0,0,5,1;0,6,0,8,5;8,8,2,5,8;0,8,2,3,4;8,0,6,1,0;];
% data05 %
patchtypeimage05=[0,0,0,0,0;0,0,0,0,0;0,0,0,0,0;0,0,0,0,0;0,0,0,0,0;0,0,0,0,6;0,0,0,0,1;0,0,1,0,8;0,0,5,3,6;3,8,8,0,8;0,8,7,1,3;2,2,0,5,3;];

patchtype=patchtypeimage05;
[array_height,array_width] = size(patchtype);    
     
    for level=0:8
        level_count=0;
        for p=1:array_height
            for q=1:array_width
                if level == patchtype(p,q)
                    level_count = level_count+1;
                end
            end
        end
        TotalHistogramCount(level+1)=level_count;
    end   
    
    image_height=array_height;
    image_width=array_width;
     %--- Markov Feaature Transition Probability Matrix ---%
    for a=0:8
        for b=0:8 
%     for a=0:14
%         for b=0:14 

            % Transition Probability Matrix of subdiagonal Function Ms(a,b) %
            msindex_count=0;
            for s=1:image_height
                for t=1:image_width
                    if (t>1 && s<image_height)
                        if (patchtype(s,t)==a && patchtype(s+1,t-1)==b)
                            msindex_count = msindex_count+1;
                        end
                    end
                end
            end        
            ms_matrix_feature(a+1,b+1) = msindex_count/TotalHistogramCount(a+1);
            ms_feature(9*a+b+1) = ms_matrix_feature(a+1,b+1);
%             ms_feature(15*a+b+1) = ms_matrix_feature(a+1,b+1);
            clear msindex_count;

            % Transition Probability Matrix of vertical Mv(a,b) %
            mvindex_count=0;
            for s=1:image_height
                for t=1:image_width
                    if s<image_height
                        if (patchtype(s,t)==a && patchtype(s+1,t)==b)
                            mvindex_count = mvindex_count+1;
                        end
                    end
                end
            end
            mv_matrix_feature(a+1,b+1) = mvindex_count/TotalHistogramCount(a+1);
            mv_feature(9*a+b+1) = mv_matrix_feature(a+1,b+1);
%             mv_feature(15*a+b+1) = mv_matrix_feature(a+1,b+1);
            clear mvindex_count;

            % Transition Probability Matrix of diagonal Md(a,b) %
            mdindex_count=0;
            for s=1:image_height
                for t=1:image_width
                    if (t<image_width && s<image_height)
                        if (patchtype(s,t)==a && patchtype(s+1,t+1)==b)
                            mdindex_count = mdindex_count+1;
                        end
                    end
                end
            end        
            md_matrix_feature(a+1,b+1) = mdindex_count/TotalHistogramCount(a+1);
            md_feature(9*a+b+1) = md_matrix_feature(a+1,b+1);
%             md_feature(15*a+b+1) = md_matrix_feature(a+1,b+1);
            clear mdindex_count;        
        end
    end 
    imagefeature = [(TotalHistogramCount(1:9)/(image_height*image_width))',ms_feature,mv_feature,md_feature];
    

% patchtypeimage = [2,2,6,6,2,2,1,1,5;2,2,6,6,2,2,1,1,5;4,4,7,7,2,2,3,3,6;4,4,7,7,2,2,3,3,6;5,5,5,5,2,2,6,6,3;5,5,5,5,2,2,6,6,3;7,7,2,2,2,2,7,7,5;7,7,2,2,2,2,7,7,5;0,0,7,7,3,3,8,8,2;0,0,7,7,3,3,8,8,2;2,2,5,5,8,8,3,3,4;2,2,5,5,8,8,3,3,4;0,0,3,3,0,0,6,6,6;0,0,3,3,0,0,6,6,6;4,4,3,3,0,0,7,7,7;4,4,3,3,0,0,7,7,7;0,0,7,7,7,7,6,6,4;0,0,7,7,7,7,6,6,4;8,8,4,4,5,5,6,6,7;8,8,4,4,5,5,6,6,7;]*10
% [i,j]=size(patchtypeimage);
% 
% imshow(patchtypeimage,[0 255]);
% 
% for s=1:i
%     for t=1:j     
%         patch_index = patchtypeimage(s,t);
%         switch patch_index
%             case patch_index==0
%                 if (patchtypeimage(s+1,t)==0||patchtypeimage(s+1,t)==1||patchtypeimage(s+1,t)==3||patchtypeimage(s+1,t)==4||patchtypeimage(s+1,t)==5)
%                     patchtypeimage_show(s,t) = 255;
%                 end                
%             case patch_index==1
%                 if (patchtypeimage(s+1,t)==1||patchtypeimage(s+1,t)==0||patchtypeimage(s+1,t)==3||patchtypeimage(s+1,t)==4||patchtypeimage(s+1,t)==5||patchtypeimage(s+1,t)==7||patchtypeimage(s+1,t)==8)
%                     patchtypeimage_show(s,t) = 255;
%                 end  
%             case patch_index==3
%                 if (patchtypeimage(s+1,t)==3||patchtypeimage(s+1,t)==0||patchtypeimage(s+1,t)==1||patchtypeimage(s+1,t)==4||patchtypeimage(s+1,t)==5)
%                     patchtypeimage_show(s,t) = 255;
%                 end         
%             case patch_index==4
%                 if (patchtypeimage(s+1,t)==4||patchtypeimage(s+1,t)==0||patchtypeimage(s+1,t)==1||patchtypeimage(s+1,t)==3||patchtypeimage(s+1,t)==5||patchtypeimage(s+1,t)==7||patchtypeimage(s+1,t)==8)
%                     patchtypeimage_show(s,t) = 255;
%                 end 
%             case patch_index==5
%                 if (patchtypeimage(s+1,t)==5||patchtypeimage(s+1,t)==3||patchtypeimage(s+1,t)==4||patchtypeimage(s+1,t)==7||patchtypeimage(s+1,t)==8)
%                     patchtypeimage_show(s,t) = 255;
%                 end
%             case patch_index==7
%                 if (patchtypeimage(s+1,t)==7||patchtypeimage(s+1,t)==0||patchtypeimage(s+1,t)==1||patchtypeimage(s+1,t)==3||patchtypeimage(s+1,t)==4||patchtypeimage(s+1,t)==5||patchtypeimage(s+1,t)==8)
%                     patchtypeimage_show(s,t) = 255;
%                 end 
%             case patch_index==8
%                 if (patchtypeimage(s+1,t)==8||patchtypeimage(s+1,t)==3||patchtypeimage(s+1,t)==4||patchtypeimage(s+1,t)==5||patchtypeimage(s+1,t)==7)
%                     patchtypeimage_show(s,t) = 255;
%                 end 
%             otherwise
%                 patchtypeimage_show(s,t) = 20;
%         end
%     end
% end
% imshow(patchtypeimage_show,[0 255]);


% % orgimage = [138 132 153 153 138 149;74 90 112 139 152 122;63 72 85 74 68 61;70 75 61 40 34 35]
% % orgimage = [64 64 64 64 64 64;64 64 64 64 64 64;64 64 64 64 64 64;64 64 64 64 64 64]
% % orgimage = [69,68,68,68,68,68;69,69,69,69,69,69;69,69,70,70,70,70;70,71,71,71,71,71]
% orgimage = [69,69,69,72,72,72;69,69,69,72,72,72;69,69,69,72,72,72;70,70,70,72,72,72]
% 
% p=2;
% q=3;
% mini_square(1,1) = orgimage(p,q);
% mini_square(1,2) = orgimage(p,q+1);
% mini_square(2,1) = orgimage(p+1,q);
% mini_square(2,2) = orgimage(p+1,q+1);
% 
% patche0 = [round(((orgimage(p,q-1)+mini_square(1,1))/2)) mini_square(1,1) mini_square(1,2);round(((orgimage(p+1,q-1)+mini_square(2,1))/2)) mini_square(2,1) mini_square(2,2)];
% patche1 = [round(((orgimage(p,q-1)+mini_square(1,1))/2)) mini_square(1,1) mini_square(1,2);mini_square(2,1) round(((mini_square(2,1)+mini_square(2,2))/2)) mini_square(2,2)];
% patche2 = [round(((orgimage(p,q-1)+mini_square(1,1))/2)) mini_square(1,1) mini_square(1,2);mini_square(2,1) mini_square(2,2) round(((orgimage(p+1,q+2)+mini_square(2,2))/2))];
% patche3 = [mini_square(1,1) round(((mini_square(1,1)+mini_square(1,2))/2)) mini_square(1,2);round(((orgimage(p+1,q-1)+mini_square(2,1))/2)) mini_square(2,1) mini_square(2,2)];
% patche4 = [mini_square(1,1) round(((mini_square(1,1)+mini_square(1,2))/2)) mini_square(1,2);mini_square(2,1) round(((mini_square(2,1)+mini_square(2,2))/2)) mini_square(2,2)];
% patche5 = [mini_square(1,1) round(((mini_square(1,1)+mini_square(1,2))/2)) mini_square(1,2);mini_square(2,1) mini_square(2,2) round(((orgimage(p+1,q+2)+mini_square(2,2))/2))];
% patche6 = [mini_square(1,1) mini_square(1,2) round(((orgimage(p,q+2)+mini_square(1,2))/2));round(((orgimage(p+1,q-1)+mini_square(2,1))/2)) mini_square(2,1) mini_square(2,2)];
% patche7 = [mini_square(1,1) mini_square(1,2) round(((orgimage(p,q+2)+mini_square(1,2))/2));mini_square(2,1) round(((mini_square(2,1)+mini_square(2,2))/2)) mini_square(2,2)];
% patche8 = [mini_square(1,1) mini_square(1,2) round(((orgimage(p,q+2)+mini_square(1,2))/2));mini_square(2,1) mini_square(2,2) round(((orgimage(p+1,q+2)+mini_square(2,2))/2))];
% 
% for a = 0:1
%     for b = 0:1
%         tmp_referee_pattern = [orgimage(p-1+a,q-1+b) orgimage(p-1+a,q+b) orgimage(p-1+a,q+1+b);orgimage(p+1+a,q-1+b) orgimage(p+1+a,q+b) orgimage(p+1+a,q+1+b)]
%         if (a==0 && b==0)
%             referee_pattern = tmp_referee_pattern;
%         else 
%             referee_pattern = referee_pattern + tmp_referee_pattern;
%         end
%     end
% end
% referee_pattern = (referee_pattern/4);
% 
% % patch_criterion = [2,2,2,2,2,2,2,2];
% patch_criterion(1) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche0(1,:) patche0(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche0(1,:) patche0(2,:)]));
% patch_criterion(2) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche1(1,:) patche1(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche1(1,:) patche1(2,:)]));
% patch_criterion(3) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche2(1,:) patche2(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche2(1,:) patche2(2,:)]));
% patch_criterion(4) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche3(1,:) patche3(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche3(1,:) patche3(2,:)]));
% patch_criterion(5) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche4(1,:) patche4(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche4(1,:) patche4(2,:)]));
% patch_criterion(6) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche5(1,:) patche5(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche5(1,:) patche5(2,:)]));
% patch_criterion(7) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche6(1,:) patche6(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche6(1,:) patche6(2,:)]));
% patch_criterion(8) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche7(1,:) patche7(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche7(1,:) patche7(2,:)]));
% patch_criterion(9) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patche8(1,:) patche8(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patche8(1,:) patche8(2,:)]));
% 
% for n=1:100
% [patch_value patch_index]=max(patch_criterion)
% % clear patch_index patch_value patch_criterion;
% clear patch_index;
% end


% %--------------------------------------------------------------------- �H�U�O�ƥ� ---------------------------------------------------------------------%
%     for m=(image_height-2):(-2):2
%         p=m+1;
%         for n=(image_width-3):(-2):2
%             q=n+1;
%             % Image patchtype %
%             patch_index = patchtypeimage(p,q);            
%             
%             % My propose %             
%             switch patch_index
%                 case{0,1}
%                     parent_patch_index = patchtypeimage(p-1,q-1);                    
%                     if (parent_patch_index==2 || parent_patch_index==5 || parent_patch_index==8)
%                         Ms_patchtypeimage(p,q) = 255;
%                         Ms_patchtypeimage(p,q+1) = 255;
%                         Ms_patchtypeimage(p+1,q) = 255;
%                         Ms_patchtypeimage(p+1,q+1) = 255;
%                         clear parent_patch_index;
%                     else
%                         Md_patchtypeimage(p,q) = 0;
%                         Md_patchtypeimage(p,q+1) = 0;
%                         Md_patchtypeimage(p+1,q) = 0;
%                         Md_patchtypeimage(p+1,q+1) = 0;
%                     end                    
%                     parent_patch_index = patchtypeimage(p-1,q); 
%                     switch parent_patch_index                     
%                         case{0,1,3,4,6,7}
%                             Mv_patchtypeimage(p,q) = 255;
%                             Mv_patchtypeimage(p,q+1) = 255;
%                             Mv_patchtypeimage(p+1,q) = 255;
%                             Mv_patchtypeimage(p+1,q+1) = 255;
%                             clear parent_patch_index;                            
%                     end
%                     
%                 case{3,4,5}
%                     parent_patch_index = patchtypeimage(p-1,q); 
%                     switch parent_patch_index                     
%                         case{0,1,2,3,4,5,6,7,8}
%                             Mv_patchtypeimage(p,q) = 255;
%                             Mv_patchtypeimage(p,q+1) = 255;
%                             Mv_patchtypeimage(p+1,q) = 255;
%                             Mv_patchtypeimage(p+1,q+1) = 255;
%                             clear parent_patch_index;                            
%                     end
%                     
%                 case{7,8}
%                     parent_patch_index = patchtypeimage(p-1,q); 
%                     switch parent_patch_index                     
%                         case{1,2,4,5,7,8}
%                             Mv_patchtypeimage(p,q) = 255;
%                             Mv_patchtypeimage(p,q+1) = 255;
%                             Mv_patchtypeimage(p+1,q) = 255;
%                             Mv_patchtypeimage(p+1,q+1) = 255;
%                             clear parent_patch_index;
%                     end     
%                     parent_patch_index = patchtypeimage(p-1,q+2);                    
%                     if (parent_patch_index==0 || parent_patch_index==3 || parent_patch_index==6)
%                         Md_patchtypeimage(p,q) = 255;
%                         Md_patchtypeimage(p,q+1) = 255;
%                         Md_patchtypeimage(p+1,q) = 255;
%                         Md_patchtypeimage(p+1,q+1) = 255;
%                         clear parent_patch_index;
%                     else
%                         Md_patchtypeimage(p,q) = 0;
%                         Md_patchtypeimage(p,q+1) = 0;
%                         Md_patchtypeimage(p+1,q) = 0;
%                         Md_patchtypeimage(p+1,q+1) = 0;
%                     end
%             end
%             
%         end
%     end
%     
% figure(2);
% % imagesc(Ms_patchtypeimage);
% imshow(Ms_patchtypeimage);
% figure(3);
% % imagesc(Mv_patchtypeimage);
% imshow(Mv_patchtypeimage);
% figure(4);
% % imagesc(Md_patchtypeimage);
% imshow(Md_patchtypeimage);
% 
% tmp_a =and(Ms_patchtypeimage,Mv_patchtypeimage);
% tmp_b = and(tmp_a,Md_patchtypeimage);
% figure(5);
% % imagesc(Md_patchtypeimage);
% imshow(tmp_b);
