clear all;
clc;
close all;

OpenPathName='D:\ucid.v2\SC10';
dir_source=dir(OpenPathName);

ImageNo=0;
% for item=4:5


%--- Clock Time ---%
starting_clock = fix(clock)

for item=4:size(dir_source,1)
    
    fix(clock)
    
    FileName_s=dir_source(item).name;
    FullPathName_s = [OpenPathName,'\',FileName_s];
    orgimage=imread(FullPathName_s);
    Z=imread(FullPathName_s);
    figure(1),imagesc(Z);
    
    
    %--- Transform to Graylevel Image ---%
    orgimage = rgb2gray(orgimage);
    orgimage = double(orgimage);
    [image_height,image_width]=size(orgimage); 
    

    %--- Generate Patch Number ---%
    % Initialization %
    for s=1:image_height
        for t=1:image_width
            patchtypeimage(s,t)=20;
        end
    end
    
    
    % Produce Patch Number on Non-edage State %
    for m=1:2:(image_height-2)
        p=m+1;
        for n=1:2:(image_width-3)
            q=n+1;
            
            %%--- Image Mini-squares ---%%
            minisquare(1,1) = orgimage(p,q);
            minisquare(1,2) = orgimage(p,q+1);
            minisquare(2,1) = orgimage(p+1,q);
            minisquare(2,2) = orgimage(p+1,q+1);
            
            %%--- Mini-Squares of referee pattern ---%%
            %   tmp_referee_pattern(1,1) = orgimage(p-1+a,q-1+b);   %
            %   tmp_referee_pattern(1,2) = orgimage(p-1+a,q+b);     %
            %   tmp_referee_pattern(1,3) = orgimage(p-1+a,q+1+b);   %
            %   tmp_referee_pattern(2,1) = orgimage(p+1+a,q-1+b);   %
            %   tmp_referee_pattern(2,2) = orgimage(p+1+a,q+b);     %
            %   tmp_referee_pattern(2,3) = orgimage(p+1+a,q+1+b);   %                
            for a = 0:1
                for b = 0:1    
                    tmp_referee_pattern = [orgimage(p-1+a,q-1+b) orgimage(p-1+a,q+b) orgimage(p-1+a,q+1+b);orgimage(p+1+a,q-1+b) orgimage(p+1+a,q+b) orgimage(p+1+a,q+1+b)];
                    if (a==0 && b==0)
                        referee_pattern = tmp_referee_pattern;
                    else
                        referee_pattern = referee_pattern + tmp_referee_pattern;
                    end                                              
                end
            end
            referee_pattern = (referee_pattern/4);

            %%--- Mini-Squares of patches ---%%
               
                patch0 = [round(((orgimage(p,q-1)+minisquare(1,1))/2)) minisquare(1,1) minisquare(1,2);round(((orgimage(p+1,q-1)+minisquare(2,1))/2)) minisquare(2,1) minisquare(2,2)];
                patch1 = [round(((orgimage(p,q-1)+minisquare(1,1))/2)) minisquare(1,1) minisquare(1,2);minisquare(2,1) round(((minisquare(2,1)+minisquare(2,2))/2)) minisquare(2,2)];
                patch2 = [round(((orgimage(p,q-1)+minisquare(1,1))/2)) minisquare(1,1) minisquare(1,2);minisquare(2,1) minisquare(2,2) round(((orgimage(p+1,q+2)+minisquare(2,2))/2))];
                patch3 = [minisquare(1,1) round(((minisquare(1,1)+minisquare(1,2))/2)) minisquare(1,2);round(((orgimage(p+1,q-1)+minisquare(2,1))/2)) minisquare(2,1) minisquare(2,2)];
                patch4 = [minisquare(1,1) round(((minisquare(1,1)+minisquare(1,2))/2)) minisquare(1,2);minisquare(2,1) round(((minisquare(2,1)+minisquare(2,2))/2)) minisquare(2,2)];
                patch5 = [minisquare(1,1) round(((minisquare(1,1)+minisquare(1,2))/2)) minisquare(1,2);minisquare(2,1) minisquare(2,2) round(((orgimage(p+1,q+2)+minisquare(2,2))/2))];
                patch6 = [minisquare(1,1) minisquare(1,2) round(((orgimage(p,q+2)+minisquare(1,2))/2));round(((orgimage(p+1,q-1)+minisquare(2,1))/2)) minisquare(2,1) minisquare(2,2)];
                patch7 = [minisquare(1,1) minisquare(1,2) round(((orgimage(p,q+2)+minisquare(1,2))/2));minisquare(2,1) round(((minisquare(2,1)+minisquare(2,2))/2)) minisquare(2,2)];
                patch8 = [minisquare(1,1) minisquare(1,2) round(((orgimage(p,q+2)+minisquare(1,2))/2));minisquare(2,1) minisquare(2,2) round(((orgimage(p+1,q+2)+minisquare(2,2))/2))];

                %%--- Criterion of Cosine similarity ---%%
                patch_criterion(1) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch0(1,:) patch0(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch0(1,:) patch0(2,:)]));
                patch_criterion(2) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch1(1,:) patch1(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch1(1,:) patch1(2,:)]));
                patch_criterion(3) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch2(1,:) patch2(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch2(1,:) patch2(2,:)]));
                patch_criterion(4) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch3(1,:) patch3(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch3(1,:) patch3(2,:)]));
                patch_criterion(5) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch4(1,:) patch4(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch4(1,:) patch4(2,:)]));
                patch_criterion(6) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch5(1,:) patch5(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch5(1,:) patch5(2,:)]));
                patch_criterion(7) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch6(1,:) patch6(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch6(1,:) patch6(2,:)]));
                patch_criterion(8) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch7(1,:) patch7(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch7(1,:) patch7(2,:)]));
                patch_criterion(9) = dot([referee_pattern(1,:) referee_pattern(2,:)],[patch8(1,:) patch8(2,:)])/(norm([referee_pattern(1,:) referee_pattern(2,:)])*norm([patch8(1,:) patch8(2,:)]));
                
                %%--- Select Mini-Squares of patchtype ---%%
                [patch_value patch_index]=max(patch_criterion);
                patch_index = patch_index-1;            
                patchtypeimage(p,q) = patch_index;
                patchtypeimage(p,q+1) = patch_index;
                patchtypeimage(p+1,q) = patch_index;
                patchtypeimage(p+1,q+1) = patch_index;
                clear patch_index patch_value patch_criterion referee_pattern patch0 patch1 patch2 patch3 patch4 patch5 patch6 patch7 patch8;


        end
    end
    
    counti=0;    
    for m=1:2:(image_height-2)
        p=m+1;  
        counti=counti+1;
        countj=0;
        for n=1:2:(image_width-3)
            q=n+1;            
            countj=countj+1;
            patchtype(counti,countj) = patchtypeimage(p,q);            
        end
    end
    
    
    
    %--- Probability of patchtype for everyone ---% 
    %   TotalHistogramCount(level+1)=(sum(sum(patchtypeimage==level)))  %
    TotalHistogramCount=zeros(9,1);
    [array_height,array_width] = size(patchtype);    
     
    for level=0:8
        level_count=0;
        for p=1:array_height
            for q=1:array_width
                if level == patchtype(p,q)
                    level_count = level_count+1;
                end
            end
        end
        TotalHistogramCount(level+1)=level_count;
    end    
    
    image_height=array_height;
    image_width=array_width;
    %--- Markov Feaature Transition Probability Matrix ---%
    for a=0:8
        for b=0:8 
            
            % Transition Probability Matrix of subdiagonal Function Ms(a,b) %
            msindex_count=0;
            for s=1:(image_height-1)
                for t=1:image_width      
                    if (t>1 && s<image_height)
                        if (patchtype(s,t)==a && patchtype(s+1,t-1)==b)
                            msindex_count = msindex_count+1;
                        end
                    end
                end
            end        
            ms_matrix_feature(a+1,b+1) = msindex_count/TotalHistogramCount(a+1);
            ms_feature(9*a+b+1) = ms_matrix_feature(a+1,b+1);
            clear msindex_count;

            % Transition Probability Matrix of vertical Mv(a,b) %
            mvindex_count=0;
            for s=1:image_height
                for t=1:image_width
                    if s<image_height
                        if (patchtype(s,t)==a && patchtype(s+1,t)==b)
                            mvindex_count = mvindex_count+1;
                        end
                    end
                end
            end        
            mv_matrix_feature(a+1,b+1) = mvindex_count/TotalHistogramCount(a+1);
            mv_feature(9*a+b+1) = mv_matrix_feature(a+1,b+1);
            clear mvindex_count;

            % Transition Probability Matrix of diagonal Md(a,b) %
             mdindex_count=0;
            for s=1:image_height
                for t=1:image_width
                    if (t<image_width && s<image_height)
                        if (patchtype(s,t)==a && patchtype(s+1,t+1)==b)
                            mdindex_count = mdindex_count+1;
                        end
                    end
                end
            end        
            md_matrix_feature(a+1,b+1) = mdindex_count/TotalHistogramCount(a+1);
            md_feature(9*a+b+1) = md_matrix_feature(a+1,b+1);

            clear mdindex_count;        
        end
    end 
    imagefeature = [(TotalHistogramCount(1:9)/(image_height*image_width))',ms_feature,mv_feature,md_feature];
    
    fix(clock)
    
    %--- Save Features to SVM input file ---%
    ImageNo=ImageNo+1
    imagefeaturedata(ImageNo,:)=imagefeature;
    showitem=FileName_s
    
%     figure(1),imagesc(Z);
%     figure(2),imshow(Sobel_image);
end

%--- Clock Time ---%
ending_clock = fix(clock)
findseam_total_time = ending_clock - starting_clock

imagefeaturedataSC10 = imagefeaturedata;
save imagefeaturedataSC10.mat imagefeaturedataSC10;
