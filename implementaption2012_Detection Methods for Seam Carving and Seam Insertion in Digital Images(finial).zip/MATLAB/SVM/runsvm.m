clear all;
clc;

load imagefeaturedata_lable.mat;
training_data_label00=imagefeaturedataSC00_lable';
training_data_label10=imagefeaturedataSC10_lable';

load imagefeaturedataSC10.mat;
training_data_inst10=imagefeaturedataSC10;
load imagefeaturedataSC00.mat;
training_data_inst00=imagefeaturedataSC00;

training_data_label=[training_data_label00;training_data_label10];
training_data_inst=[training_data_inst00;training_data_inst10];

% % model = svmtrain(training_data_label, training_data_inst, '-c 1 -g 2')
% model = svmtrain(training_data_label, training_data_inst, '-c 1 -g 0.07 -b 1')
% 
% [predict_label00, accuracy00, dec_values00] = svmpredict(training_data_label00,training_data_inst00,model);
% [predict_label10, accuracy10, dec_values10] = svmpredict(training_data_label10,training_data_inst10,model);
% clear training_data_label training_data_inst model;
% training_data_label=[training_data_label00;training_data_label10;training_data_label00;training_data_label10];
% training_data_inst=[training_data_inst10;training_data_inst00;training_data_inst10;training_data_inst00];
% model = svmtrain(training_data_label, training_data_inst, '-c 1 -g 0.07 -b 1')
% [predict_label00, accuracy00, dec_values00] = svmpredict(training_data_label00,training_data_inst00,model);
% [predict_label10, accuracy10, dec_values10] = svmpredict(training_data_label10,training_data_inst10,model);
% clear training_data_label training_data_inst model;

%--- Cross Trainning Testing ---%
training_data_label=[training_data_label00;training_data_label10;training_data_label10];
training_data_inst=[training_data_inst00;training_data_inst10;training_data_inst10];
model = svmtrain(training_data_label, training_data_inst, '-c 1 -g 0.07 -v 5')
% clear training_data_label training_data_inst;

%--- ���� Trainning ---%
% predict_label1 = svmpredict(test_data_label(1:100),test_data_inst(1:100,:),model);
% predict_label2 = svmpredict(test_data_label(101:200),test_data_inst(101:200,:),model);
% predict_label3 = svmpredict(test_data_label(201:300),test_data_inst(201:300,:),model);
% predict_label4 = svmpredict(test_data_label(301:400),test_data_inst(301:400,:),model);
% predict_label5 = svmpredict(test_data_label(401:500),test_data_inst(401:500,:),model);
% predict_label6 = svmpredict(test_data_label(501:600),test_data_inst(501:600,:),model);
% predict_label7 = svmpredict(test_data_label(601:700),test_data_inst(601:700,:),model);
% predict_label8 = svmpredict(test_data_label(701:800),test_data_inst(701:800,:),model);
% predict_label9 = svmpredict(test_data_label(801:900),test_data_inst(801:900,:),model);
% predict_label10 = svmpredict(test_data_label(901:1000),test_data_inst(901:1000,:),model);
% predict_label11 = svmpredict(test_data_label(1001:1100),test_data_inst(1001:1100,:),model);
% predict_label12 = svmpredict(test_data_label(1101:1200),test_data_inst(1101:1200,:),model);
% predict_label13 = svmpredict(test_data_label(1201:1300),test_data_inst(1201:1300,:),model);
% predict_label14 = svmpredict(test_data_label(1301:1338),test_data_inst(1301:1338,:),model);

%--- �v�@ Testing ---%
% for i=1:1338
%     predict_label = svmpredict(test_data_label(i),test_data_inst(i,:),model);
% end

