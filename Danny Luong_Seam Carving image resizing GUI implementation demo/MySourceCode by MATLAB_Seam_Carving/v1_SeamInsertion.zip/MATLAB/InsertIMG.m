% Script file for experimenting with various seam functions
%
% Author: Danny Luong, 12/5/07

close all
clear all
X=imread('ucid00038.tif');
Z=imread('ucid00038.tif');

X=double(X)/255;
[rows cols dim]=size(X);
% figure(1);
% imshow(X);


figure(1)
imagesc(Z)
    figure(1)
    imagesc(Z)
    axis equal

%find gradient image of luminance channel
E1=findEnergy(X);

    figure(2)
    imshow(E1)

%     
% E1=zeros(300,500);
% E1(120,:)=1;

%finds seam calculation image
S1=findSeamImg(E1);

    figure(3)
    imshow(S1,[min(S1(:)) max(S1(:))])

% Finds seam    
SeamVector=findSeam(S1);

% %plot image with superimposed seam
% SeamedImg=SeamPlot(E1,SeamVector);
%     figure(4)
%     imshow(SeamedImg,[min(SeamedImg(:)) max(SeamedImg(:))]) 

% %remove seam
% SeamCutImg=SeamCut(X,SeamVector);
% 
%     figure(5)
%     imshow(SeamCutImg)

%find and increase N seams
M=increaseMap(X,257);
MSeamedImg=SeamPut(X,M);
figure(6)
imshow(MSeamedImg)
MAXSeamedImg=MSeamedImg;

% My Ground Truth
for i=1:257
    SeamVectorRtl=M;    
    SeamedImg=SeamPlot(MAXSeamedImg,SeamVectorRtl(:,i));
    figure(4)
    imshow(SeamedImg,[min(SeamedImg(:)) max(SeamedImg(:))]) 
    imwrite(SeamedImg,'SIMGSC10ucid00038.tif');
    MAXSeamedImg=imread('SIMGSC10ucid00038.tif');
end

imwrite(MSeamedImg,'SI10ucid00038.tif');
imwrite(MAXSeamedImg,'SIMGSC10ucid00038.tif');